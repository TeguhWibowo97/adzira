<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><i class="fas fa-user"></i> Detail Tentor</h1>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content Start-->
    <section class="content">
        <!-- isi konten disini ya gan -->
        <div class="container">
            <div class="card md-6" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="<?= base_url();?>assetAdmin/dist/img/avatar5.png" class="card-img" alt="...">
                        <button class="btn btn-warning btn-block mt-2" data-toggle="modal" data-target="#ModalEditDataTentor">
                            <i class="fas fa-edit"></i> Edit Data
                        </button>
                    </div>
                    <div class="col-md-8 ">
                    <div class="card-body">
                        <h5 class="card-title my-3">Detail Lengkap Tentor</h5>
                        <table class="table mt-2">
                            <tbody>
                            <tr>
                                <th scope="row">Nama</th>
                                <td>:</td>
                                <td><?= $tentor['nama'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">Alamat</th>
                                <td>:</td>
                                <td><?= $tentor['alamat'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">No. Telepon</th>
                                <td>:</td>
                                <td><?= $tentor['no_tlp'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">Bidang Keahlian</th>
                                <td>:</td>
                                <td><?= $tentor['bidang_keahlian'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">Sekolah</th>
                                <td>:</td>
                                <td><?= $tentor['sekolah'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">Jurusan</th>
                                <td>:</td>
                                <td><?= $tentor['jurusan'];?></td>
                            </tr>
                            <tr>
                                <th scope="row">Semester</th>
                                <td>:</td>
                                <td><?= $tentor['semester'];?></td>
                            </tr>
                            </tbody>
                        </table>
                        <p class="card-text text-center"><small class="text-muted">Data terakhir diubah 2 hari yang lalu.</small></p>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Main content End -->
</div>